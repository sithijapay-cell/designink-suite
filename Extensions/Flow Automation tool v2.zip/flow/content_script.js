if (typeof window.__FLOW_PRO_LOADED === 'undefined') {
    window.__FLOW_PRO_LOADED = true;

    var isStopped = false;
    var flowPort = null;

function logAction(msg) {
    console.log("Flow Pro:", msg);
}

const delay = ms => new Promise(res => setTimeout(res, ms));

async function clickElement(element) {
    if (!element) return;
    
    // Natively trigger standard click. Emulated pointer/mouse sequences 
    // often crash modern React if the component unmounts mid-dispatch.
    try {
        element.click();
    } catch(err) {
        console.warn("Click issue:", err);
    }
    
    await delay(500); // Standard 500ms delay between actions
}

function getByXPath(path, context = document) {
    return document.evaluate(path, context, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}

// Port connection strictly defined per instructions
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === "flow-auto-port") {
        flowPort = port;
        port.onMessage.addListener(async (request) => {
            if (request.action === "ping") {
                port.postMessage({ action: "pong" });
                return;
            }
            if (request.action === "stop") {
                isStopped = true;
                return;
            }
            if (request.action === "runAction") {
                isStopped = false;
                try {
                    await runAction(request.prompt, request.settings);
                    if (!isStopped) port.postMessage({ success: true });
                    else port.postMessage({ success: false, error: 'Stopped by user' });
                } catch(err) {
                    logAction(`Error: ${err.message || err.toString()}`);
                    port.postMessage({ success: false, error: err.message || err.toString() });
                }
            }
            if (request.action === "downloadAll") {
                isStopped = false;
                try {
                    await downloadAllGenImages(request.settings);
                    if (!isStopped) port.postMessage({ success: true });
                    else port.postMessage({ success: false, error: 'Stopped by user' });
                } catch(err) {
                    logAction(`Error: ${err.message || err.toString()}`);
                    port.postMessage({ success: false, error: err.message || err.toString() });
                }
                return;
            }
        });
        port.onDisconnect.addListener(() => {
            flowPort = null;
        });
    }
});

// Fallback logic in case the Sidepanel forces standard messaging instead of Port
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "ping") {
        sendResponse({ success: true, message: "pong" });
        return true;
    }
    
    if (request.action === "stop") {
        isStopped = true;
        sendResponse({ success: true });
        return true;
    }
    
    if (request.action === "runAction") {
        isStopped = false;
        runAction(request.prompt, request.settings)
            .then(() => {
                if (!isStopped) sendResponse({ success: true });
                else sendResponse({ success: false, error: 'Stopped by user' });
            })
            .catch(err => {
                logAction(`Error: ${err.message || err.toString()}`);
                sendResponse({ success: false, error: err.message || err.toString() });
            });
        return true; 
    }
    
    if (request.action === "downloadAll") {
        isStopped = false;
        downloadAllGenImages(request.settings)
            .then(() => {
                if (!isStopped) sendResponse({ success: true });
                else sendResponse({ success: false, error: 'Stopped by user' });
            })
            .catch(err => {
                logAction(`Error: ${err.message || err.toString()}`);
                sendResponse({ success: false, error: err.message || err.toString() });
            });
        return true;
    }
});

// The core workflow defined by the Action requirements
async function runAction(prompt, settings) {
    logAction("Step 1 (Focus): Click inside prompt editor");
    
    // Add multiple selectors for editor in case Google updated it
    let editor = document.querySelector('div[data-slate-editor="true"]') 
              || document.querySelector('div[contenteditable="true"]')
              || document.querySelector('textarea')
              || document.querySelector('input[type="text"][placeholder*="prompt"]');

    if (!editor) {
        // Broadest fallback
        const editables = Array.from(document.querySelectorAll('[contenteditable="true"]'));
        if (editables.length > 0) editor = editables[editables.length - 1]; // usually the main one is the last or largest
    }
    
    if (!editor) throw new Error("Could not find the prompt editor.");

    try { editor.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e){}
    await delay(300);
    
    editor.focus();
    await clickElement(editor);
    await delay(300);

    const selection = window.getSelection();

    // Step 2 (Prompt): Injecting new prompt safely...
    logAction("Step 2 (Prompt): Injecting new prompt safely...");

    try {
        // Deep target actual Text Nodes to bypass SlateJS's structural Element maps completely!
        // This natively prevents "Cannot resolve a Slate node from DOM node: [object HTMLSpanElement]" 
        // because we are explicitly targeting Text leaves, not the HTML elements.
        const textNodes = [];
        const walker = document.createTreeWalker(editor, NodeFilter.SHOW_TEXT, null, false);
        let node;
        while ((node = walker.nextNode())) {
            // Filter out placeholder components or unrelated nested UI text
            if (node.parentElement && !node.parentElement.hasAttribute('data-slate-placeholder')) {
                textNodes.push(node);
            }
        }

        if (textNodes.length > 0) {
            const startNode = textNodes[0];
            const endNode = textNodes[textNodes.length - 1];
            
            const range = document.createRange();
            range.setStart(startNode, 0);
            range.setEnd(endNode, endNode.nodeValue.length);
            
            selection.removeAllRanges();
            selection.addRange(range);
        }
    } catch(e) {
        logAction(" -> TextNode extraction Warning: " + e.toString());
        // Standard full-clear fallback if TreeWalker failed gracefully
        editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true, cancelable: true }));
    }

    // CRITICAL: Heavy memory load delay! At 80+ items, React is excessively slow to reconcile Virtual/Physical DOM.
    // If we paste before React recognizes the selection, Slate tries to locate unmapped elements and crashes.
    await delay(500);

    // Attempt 1: Trusted Paste Event. (Most compatible with SlateJS)
    const dt = new DataTransfer();
    dt.setData('text/plain', prompt);
    const pasteEvent = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
    editor.dispatchEvent(pasteEvent);
    
    await delay(500); // Give Slate generous time to parse and chunk the pasted text before verifying

    // Attempt 2: Synthetic Typing
    if (!editor.textContent.includes(prompt.substring(0, Math.min(prompt.length, 10)))) {
        logAction(" -> Paste unconfirmed. Falling back to React/Slate-safe InputEvents...");
        editor.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: prompt, bubbles: true, cancelable: true }));
        editor.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: prompt, bubbles: true, cancelable: true }));
    }

    // Attempt to notify any generic React synthetic event listeners directly if available
    try {
        let reactTracker = editor._valueTracker;
        if (reactTracker) reactTracker.setValue(prompt);
    } catch(e){}

    editor.dispatchEvent(new Event('change', { bubbles: true }));

    // Trigger Enter key to potentially tell React the form is ready
    editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true, cancelable: true }));
    await delay(800); // Increased delay for UI response on slower laptops

    logAction("Step 3 (Menu): Finding and clicking Settings dropdown...");
    
    // Attempt 1: Aria Labels
    let settingsBtn = document.querySelector('button[aria-label="Settings"], button[aria-label="Model & Settings"], button[aria-label="Generation settings"]');
    
    // Attempt 2: Tune Icon (usually the icon used for settings)
    if (!settingsBtn) {
        const icons = Array.from(document.querySelectorAll('i.google-symbols, span.google-symbols, .material-symbols-outlined'));
        const tuneIcon = icons.find(i => i.textContent.trim() === 'tune');
        if (tuneIcon) settingsBtn = tuneIcon.closest('button');
    }

    // Attempt 3: Radix UI specific
    if (!settingsBtn) {
        settingsBtn = Array.from(document.querySelectorAll('button[id^="radix-"]')).find(b => b.hasAttribute('aria-expanded'));
    }

    // Attempt 4: Relative to Create button
    if (!settingsBtn) {
        const createBtns = Array.from(document.querySelectorAll('button')).filter(b => b.textContent.includes('Create') || b.getAttribute('aria-label') === 'Run prompt');
        if (createBtns.length > 0 && createBtns[0].previousElementSibling && createBtns[0].previousElementSibling.tagName === 'BUTTON') {
            settingsBtn = createBtns[0].previousElementSibling;
        }
    }

    if (settingsBtn) {
        logAction(" -> Settings button found. Checking if already open...");
        const expanded = settingsBtn.getAttribute('aria-expanded');
        // Only click if it's explicitly closed, or if we can't tell (to be safe)
        if (expanded !== 'true') {
            await clickElement(settingsBtn);
            await delay(1000); // UI transition time wait
        } else {
            // Already open
            await delay(200); 
        }
    } else {
        logAction(" -> Settings button not found. Searching for internal menu items directly...");
    }

    logAction(`Step 4 (Configure): Modifying settings...`);
    
    logAction(` -> Click "${settings.type}" mode`);
    const typeBtn = getByXPath(`//button[contains(., '${settings.type}')]`);
    if (typeBtn) await clickElement(typeBtn);

    // Instead of clicking document.body (which crashes some React modal boundaries),
    // click the settings button again to toggle it closed cleanly.
    if (settingsBtn) {
        await clickElement(settingsBtn);
    }
    await delay(300); // Much faster pause after configuring settings

    logAction("Step 5 (Submit): Click the 'Create' arrow button");
    let genBtn = document.querySelector('button.bMhrec');
    
    // Fallback checking
    if (!genBtn) {
        const allBtns = Array.from(document.querySelectorAll('button, [role="button"]'));
        genBtn = allBtns.find(b => {
             const t = (b.textContent || '').toLowerCase();
             const aria = (b.getAttribute('aria-label') || '').toLowerCase();
             const title = (b.getAttribute('title') || '').toLowerCase();
             const html = (b.innerHTML || '').toLowerCase();
             
             return t.includes("create") || t.includes("generate") || t.includes("run") || b.innerHTML.includes("arrow_forward") || html.includes("send") || html.includes("spark") || aria.includes('run') || aria.includes('generate') || aria.includes('create') || title.includes('run') || title.includes('generate');
        });
    }
    
    if (!genBtn) {
        logAction(" -> Create button not uniquely identified. Defaulting to last button in header area...");
        const headerBtns = Array.from(document.querySelectorAll('header button, [role="banner"] button, nav button, main button'));
        if (headerBtns.length > 0) genBtn = headerBtns[headerBtns.length - 1]; // usually the generate button is at the end
    }

    if (!genBtn) throw new Error("Create/Submit button not found.");

    try { genBtn.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e){}
    await delay(300);

    // Enable the button natively just in case
    genBtn.removeAttribute('disabled');
    genBtn.disabled = false;

    // CRITICAL FIX: Mark all existing tiles before we click generate so we don't instantly resolve to an old image
    logAction("Step 5.5: Marking existing board tiles to isolate new generation.");
    document.querySelectorAll('[data-tile-id], .group, img').forEach(el => {
        el.setAttribute('data-action-processed', 'true');
    });

    await delay(400); // 0.4s delay staring at the button before pressing it
    await clickElement(genBtn);

    logAction("Step 6 (Monitor): Wait for the new generation...");
    await waitForGeneration(settings);
}

function waitForGeneration(settings) {
    return new Promise((resolve, reject) => {
        let resolved = false;
        let lastRetryTime = 0;
        let foundLoadingSpinner = false; // Track if we ever saw the spinner
        
        // FOOLPROOF tracking: Count the number of actual generated tiles BEFORE we hit generate
        let previousTilesCount = document.querySelectorAll('[data-tile-id], .group').length;

        // Hard timeout to prevent infinite hangs (Increased to 5 minutes)
        const maxTimeout = setTimeout(() => {
            if (!resolved) {
                resolved = true;
                if (checkInterval) clearInterval(checkInterval);
                if (observer) observer.disconnect();
                reject(new Error("Timeout (300s): Tile never finished generating or wasn't detected."));
            }
        }, 300000);

        const checkStatus = async () => {
            if (isStopped || resolved) {
                if (!resolved) {
                    resolved = true;
                    if (checkInterval) clearInterval(checkInterval);
                    if (observer) observer.disconnect();
                    clearTimeout(maxTimeout);
                    resolve({ success: false, error: "Stopped by user." });
                }
                return;
            }

            // Check for Rate Limit Error Message First
            const errorOverlays = Array.from(document.querySelectorAll('[role="alert"], [data-sonner-toast], .toast, .snackbar, .error'));
            const errorText = errorOverlays.length > 0 ? errorOverlays.map(e => e.textContent.toLowerCase()).join(' ') : "";
            
            if (errorText.includes("too quickly") || errorText.includes("too many requests") || errorText.includes("quota")) {
                const now = Date.now();
                if (now - lastRetryTime > 4000) { 
                    lastRetryTime = now;
                    logAction(" -> Rate limit detected in alerts! Waiting 4s then retrying submit...");
                    document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
                    
                    setTimeout(() => {
                        if (isStopped || resolved) return;
                        let retryBtn = document.querySelector('button.bMhrec');
                        if (!retryBtn) {
                            const allBtns = Array.from(document.querySelectorAll('button'));
                            retryBtn = allBtns.find(b => b.textContent.includes("Create") || b.innerHTML.includes("arrow_forward"));
                        }
                        if (retryBtn) {
                            retryBtn.removeAttribute('disabled');
                            retryBtn.disabled = false;
                            retryBtn.click();
                            logAction(" -> Retry click dispatched.");
                        }
                    }, 4000); 
                }
            }

            // Step B1: Monitor for the loading UI
            const loadingOverlay = document.querySelector('div.sc-9b28a31b-0 .loading, div.sc-9b28a31b-0 [role="progressbar"], div[role="progressbar"], svg.animate-spin, [aria-busy="true"]');
            
            if (loadingOverlay) {
                foundLoadingSpinner = true;
                return; // Still generating, wait.
            }

            // Step B2: Spinner is gone. Did it actually finish generating a new tile?
            // Use logical width properties to track correctly even when tab is backgrounded
            const newImages = Array.from(document.querySelectorAll('img')).filter(img => {
                const isSized = (img.naturalWidth > 20 || img.clientWidth > 20 || img.width > 20 || (img.getBoundingClientRect && img.getBoundingClientRect().width > 20));
                return isSized && 
                       !img.hasAttribute('data-action-processed') &&
                       !img.src.includes('avatar') && !img.src.includes('logo');
            });

            // Consider it done if we see a new image, OR if the spinner appeared and is now gone
            if (newImages.length > 0 || (foundLoadingSpinner && !loadingOverlay)) {
                
                // If we found the specific image, mark it
                if (newImages.length > 0) {
                    const newImg = newImages[0];
                    newImg.setAttribute('data-action-processed', 'true');
                    newImg.setAttribute('data-auto-generated', 'true');
                    const parentTile = newImg.closest('[data-tile-id], .group, div');
                    if (parentTile) parentTile.setAttribute('data-action-processed', 'true');
                }
                
                resolved = true;
                if (checkInterval) clearInterval(checkInterval);
                if (observer) observer.disconnect();
                clearTimeout(maxTimeout);
                
                logAction("Generation complete! Skipping auto-download as requested.");
                
                try {
                    const closeBtn = document.querySelector('button[aria-label="Close"], .close-button, [data-dismiss]');
                    if (closeBtn) closeBtn.click();
                    else document.body.click();
                } catch(e){}
                
                logAction("Executing strict 4-second delay before moving to next prompt...");
                await delay(4000);
                resolve({ success: true });
            }
        };

        const checkInterval = setInterval(() => checkStatus(), 1500);
        
        let lastObserverCheck = 0;
        const observer = new MutationObserver(() => {
            const now = Date.now();
            if (now - lastObserverCheck > 800) {
                lastObserverCheck = now;
                checkStatus();
            }
        });
        observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'src'] });
    });
}

// -------------------------------------------------------------
// PHASE 2: BATCH DOWNLOAD ALL GENERATED IMAGES
// -------------------------------------------------------------
async function downloadAllGenImages(settings) {
    logAction("Starting dynamic batch download of all project images...");
    
    let downloadedCount = 0;
    let keepScanning = true;
    let emptyScans = 0;

    while (keepScanning) {
        if (isStopped) throw new Error("Stopped by user");

        // Dynamically find the FIRST visible image that is at least 50x50px (Filters out tiny icons)
        let targetImage = Array.from(document.querySelectorAll('img')).find(img => {
            const rect = img.getBoundingClientRect();
            return img.src && 
                   rect.width > 20 && rect.height > 20 && // Lowered threshold just in case grid thumbnails are small
                   !img.src.includes('avatar') && !img.src.includes('logo') && 
                   !img.hasAttribute('data-action-downloaded');
        });

        if (targetImage) {
            emptyScans = 0; // Reset empty scan counter
            downloadedCount++;
            
            try {
                logAction(`Processing Image #${downloadedCount}...`);
                
                logAction(" -> Scrolling to image and locking coordinates...");
                targetImage.scrollIntoView({ behavior: 'auto', block: 'center' });
                await delay(600); 
                
                targetImage.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
                targetImage.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
                await delay(400); 
                
                await executeDownloadOnImage(targetImage, settings);
                
                // Mark as securely downloaded
                targetImage.setAttribute('data-action-downloaded', 'true');
                logAction(`Image #${downloadedCount} downloaded! Moving to next...`);
                
                await delay(1000); // Wait before grabbing the next one
            } catch (err) {
                logAction(`Warning: Failed to download Image #${downloadedCount}. Skipping...`);
                if (targetImage) targetImage.setAttribute('data-action-downloaded', 'error'); // Mark so we skip it to prevent infinite loops
                console.error(err);
            }
        } else {
            // No un-downloaded images found right now. 
            // Try scrolling the screen to trigger React lazy-loading of older images
            logAction(" -> No new images found on screen. Scrolling viewport to trigger load...");
            
            // Method 1: Scroll the LAST explicitly loaded image directly into view
            let allProjectImages = Array.from(document.querySelectorAll('img')).filter(img => 
                img.src && !img.src.includes('avatar') && !img.src.includes('logo')
            );
            
            if (allProjectImages.length > 0) {
                let lastImage = allProjectImages[allProjectImages.length - 1];
                lastImage.scrollIntoView({ behavior: 'auto', block: 'start' }); // Pull it to the top of the screen to reveal below
            }
            
            // Method 2: Manually fire 'PageDown' events, which natively triggers React Virtualized grid listeners
            document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'PageDown', code: 'PageDown', keyCode: 34, bubbles: true }));
            window.dispatchEvent(new KeyboardEvent('keydown', { key: 'PageDown', code: 'PageDown', keyCode: 34, bubbles: true }));
            
            // Method 3: Aggressive Scroll property modification on every possible parent
            let allElements = document.querySelectorAll('main, [role="main"], [role="grid"], .overflow-y-auto, [style*="overflow-y: auto"], div.ReactVirtualized__Grid');
            allElements.forEach(el => {
                if (el.scrollHeight > el.clientHeight && el.clientHeight > 0) {
                    el.scrollTop = el.scrollHeight; // Force exactly to bottom
                    el.scrollBy(0, 1000); 
                }
            });
            window.scrollBy(0, 1500);
            
            emptyScans++;
            await delay(2500); // Give React 2.5s network time to populate the new grid images
            
            if (emptyScans >= 4) {
                // Scrolled 4 times with no new images appearing. We must be at the very bottom.
                keepScanning = false;
            }
        }
    }
    
    logAction(`All Downloads Finished. Total images processed: ${downloadedCount}`);
}

async function executeDownloadOnImage(newImage, settings) {
    return new Promise(async (resolve, reject) => {
        try {
            logAction(" -> Triggering right-click on image...");
            
            let downloadBtn = null;
            
            // Retry loop for right click in case menu doesn't immediately appear
            for (let attempt = 0; attempt < 2; attempt++) {
                logAction(` -> Right click attempt ${attempt + 1} on image...`);
                
                // Find the exact screen coordinates of the image's center
                const rect = newImage.getBoundingClientRect();
                const clientX = rect.left + (rect.width / 2);
                const clientY = rect.top + (rect.height / 2);
                
                // CRITICAL FIX: React uses invisible overlay divs over images to handle clicks.
                // We MUST dispatch the right-click directly to whatever element is visually on top!
                const targetEl = document.elementFromPoint(clientX, clientY) || newImage;
                const eventProps = { bubbles: true, cancelable: true, view: window, button: 2, buttons: 2, clientX, clientY };
                
                try { targetEl.dispatchEvent(new PointerEvent('pointerdown', eventProps)); } catch(e){}
                targetEl.dispatchEvent(new MouseEvent('mousedown', eventProps));
                targetEl.dispatchEvent(new MouseEvent('contextmenu', eventProps));
                targetEl.dispatchEvent(new MouseEvent('mouseup', eventProps));
                try { targetEl.dispatchEvent(new PointerEvent('pointerup', eventProps)); } catch(e){}
                
                await delay(1000); // Give the DOM enough time to render the portal

                // Find Download in Portal using Fallback
                let candidates = Array.from(document.querySelectorAll('[role="menuitem"], .menu-item, button, li, div, p, span')).filter(el => {
                    const rect2 = el.getBoundingClientRect();
                    const txt = (el.textContent || '').toLowerCase().trim();
                    // Ensure it's visible, contains download, and isn't a massive container
                    return (rect2.width > 0 && rect2.height > 0 && txt.includes('download') && txt.length < 35);
                });
                
                if (candidates.length > 0) {
                    // Prefer explicit menu roles
                    let menuItems = candidates.filter(c => c.getAttribute('role') === 'menuitem' || c.closest('[role="menuitem"]'));
                    let result = menuItems.length > 0 ? menuItems[0] : candidates[candidates.length - 1];
                    downloadBtn = result.closest('[role="menuitem"]') || result.closest('button') || result.closest('li') || result;
                }

                if (downloadBtn) {
                    break; // Stop retrying if found
                }
                
                logAction(" -> Download menu not found, retrying right-click...");
                document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
                await delay(500);
            }
            
            if (downloadBtn) {
                logAction(" -> Found 'Download'. Clicking it to open resolution submenu...");
                await clickElement(downloadBtn);
                await delay(1200); // Wait for resolution submenu to slide in
                
                let resBtn = null;
                if (settings.resolution) {
                    logAction(` -> Searching submenu for Resolution: ${settings.resolution}...`);
                    let resolutionSearch = settings.resolution.toLowerCase(); // "1k", "2k", "4k"
                    let altSearch = resolutionSearch === "1k" ? "original" : resolutionSearch;
                    
                    for (let i = 0; i < 6; i++) {
                        let resCandidates = Array.from(document.querySelectorAll('[role="menuitem"], .menu-item, button, div, span, li')).filter(el => {
                            const rect = el.getBoundingClientRect();
                            if (rect.width === 0 || rect.height === 0) return false;
                            
                            const txt = (el.textContent || '').toLowerCase().trim();
                            return (txt.includes(resolutionSearch) || txt.includes(altSearch)) && (txt.includes("upscaled") || txt.includes("original") || txt.length < 30);
                        });
                        
                        if (resCandidates.length > 0) {
                            let items = resCandidates.filter(c => c.getAttribute('role') === 'menuitem' || c.closest('[role="menuitem"]') || c.tagName === 'BUTTON');
                            resBtn = items.length > 0 ? items[0] : resCandidates[resCandidates.length - 1];
                            
                            if (resBtn && resBtn.tagName !== 'BUTTON' && resBtn.closest('button')) resBtn = resBtn.closest('button');
                            else if (resBtn && resBtn.tagName !== 'DIV' && resBtn.closest('[role="menuitem"]')) resBtn = resBtn.closest('[role="menuitem"]');
                            break;
                        }
                        await delay(600); // Retry 
                    }
                }
                
                if (resBtn) {
                    logAction(` -> Target found! Clicking submenu resolution: ${settings.resolution}...`);
                    await clickElement(resBtn);
                    await delay(800);
                } else if (settings.resolution) {
                    logAction(` -> Warning: Resolution '${settings.resolution}' not found in submenu.`);
                    reject(new Error("Resolution Not Found in Submenu"));
                    return;
                }
            } else {
                logAction(" -> Warning: Download button not found in the document portal after right-clicks.");
                reject(new Error("Menu Item Not Found"));
                return;
            }

            // CONCURRENCY TARGET:
            logAction(" -> Executed download trigger. Closing menus...");
            document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
            await delay(300);
            document.body.click(); 
            await delay(1500); // Wait 1.5 seconds to avoid Google Glitch before triggering next image download
            resolve(); 

        } catch(err) {
            reject(err);
        }
    });
}

} // End Initialization Check
