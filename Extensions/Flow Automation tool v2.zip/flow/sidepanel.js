let prompts = [];
let isRunning = false;
let currentIndex = 0;
let tabPort = null;

// UI Elements
const fileInput = document.getElementById('fileInput');
const pasteInput = document.getElementById('pasteInput');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const startSpinner = document.getElementById('startSpinner');
const startBtnText = document.getElementById('startBtnText');
const downloadBtn = document.getElementById('downloadBtn');
const downloadSpinner = document.getElementById('downloadSpinner');
const downloadBtnText = document.getElementById('downloadBtnText');
const cardsContainer = document.getElementById('cardsContainer');
const progressFill = document.getElementById('progressFill');

function getSettings() {
  return {
    type: document.getElementById('typeSelect').value,
    resolution: document.querySelector('input[name="res"]:checked').value
  };
}

function renderCards() {
  cardsContainer.innerHTML = '';
  prompts.forEach((prompt, index) => {
    const card = document.createElement('div');
    card.className = `prompt-card`;
    card.id = `card-${index}`;
    
    // Status Icon
    let iconHTML = `<span class="status-icon status-pending">⏳</span>`;
    
    card.innerHTML = `
      <div class="prompt-text" title="${prompt.replace(/"/g, '&quot;')}">${index + 1}. ${prompt}</div>
      ${iconHTML}
    `;
    cardsContainer.appendChild(card);
  });
  updateProgressUI();
}

function updateCardStatus(index, status) {
  const card = document.getElementById(`card-${index}`);
  if (!card) return;
  
  // Reset classes
  card.className = 'prompt-card';
  card.classList.add('active'); // highlight current row
  if (status !== 'processing') card.classList.remove('active');
  
  let iconHTML = '';
  if (status === 'processing') {
    iconHTML = `<div class="spinner"></div>`;
  } else if (status === 'success') {
    card.classList.add('success');
    iconHTML = `<span class="status-icon status-success">✔</span>`;
  } else if (status === 'failed') {
    card.classList.add('failed');
    iconHTML = `<span class="status-icon status-error">✖</span>`;
  } else {
    iconHTML = `<span class="status-icon status-pending">⏳</span>`;
  }
  
  const iconTarget = card.querySelector('.status-icon') || card.querySelector('.spinner');
  if (iconTarget) {
      iconTarget.outerHTML = iconHTML;
  }
  
  // Auto-scroll vertically if necessary to show active card
  if (status === 'processing') {
      card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) {
    startBtn.disabled = true;
    return;
  }
  Papa.parse(file, {
    complete: (results) => {
      prompts = results.data.map(row => (Array.isArray(row) ? row[0] : row)).filter(p => typeof p === 'string' && p.trim() !== '');
      startBtn.disabled = prompts.length === 0;
      currentIndex = 0;
      renderCards();
    }
  });
});

document.getElementById('loadPastedBtn').addEventListener('click', () => {
  const text = pasteInput.value;
  if (!text || !text.trim()) return;
  prompts = text.split('\n').map(p => p.trim()).filter(p => p !== '');
  startBtn.disabled = prompts.length === 0;
  currentIndex = 0;
  renderCards();
});

// Port Handshake Re-Establishment Strategy 
function ensureConnection(tabId) {
    return new Promise((resolve) => {
        chrome.tabs.sendMessage(tabId, { action: "ping" }, (res) => {
            if (chrome.runtime.lastError || !res) {
                console.log("Content script missing. Auto-injecting...");
                chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    files: ['content_script.js']
                }, () => {
                    if (chrome.runtime.lastError) {
                        console.error("Injection failed:", chrome.runtime.lastError);
                        resolve(false);
                    } else {
                        setTimeout(() => connectPort(tabId, resolve), 300);
                    }
                });
            } else {
                connectPort(tabId, resolve);
            }
        });
    });
}

function connectPort(tabId, resolve) {
    if (tabPort) {
        try {
            tabPort.postMessage({ action: "ping" });
            resolve(true);
            return;
        } catch(e) {
            tabPort = null;
        }
    }
    
    try {
        tabPort = chrome.tabs.connect(tabId, { name: "flow-auto-port" });
        
        let connected = false;
        const msgListener = (msg) => {
            if (msg.action === "pong") connected = true;
        };
        tabPort.onMessage.addListener(msgListener);
        
        tabPort.onDisconnect.addListener(() => {
            tabPort = null;
            console.log("Flow Port disconnected. Sidepanel will reconnect if generation continues.");
        });
        
        tabPort.postMessage({ action: "ping" });
        
        setTimeout(() => {
            if (tabPort) tabPort.onMessage.removeListener(msgListener);
            if (connected) resolve(true);
            else { tabPort = null; resolve(false); }
        }, 300);
    } catch(e) {
        tabPort = null;
        resolve(false);
    }
}

startBtn.addEventListener('click', async () => {
  if (prompts.length === 0) return;
  isRunning = true;
  
  // UI Loading State
  startBtn.disabled = true;
  downloadBtn.disabled = true;
  startBtnText.innerText = "RUNNING...";
  startSpinner.style.display = "block";
  stopBtn.style.display = "block";

  chrome.tabs.query({active: true, currentWindow: true}, async (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.url.includes('labs.google/fx')) {
      alert("Please navigate to Google AI Studio Flow first.");
      stopGeneration();
      return;
    }
    
    // Perform fresh connection
    if (tabPort) { tabPort.disconnect(); tabPort = null; }
    await ensureConnection(tab.id);
    
    startAutomation(tab.id, getSettings());
  });
});

stopBtn.addEventListener('click', stopGeneration);

function stopGeneration() {
  isRunning = false;
  startBtn.disabled = false;
  downloadBtn.disabled = false;
  startBtnText.innerText = "GENERATE ALL";
  downloadBtnText.innerText = "DOWNLOAD ALL";
  startSpinner.style.display = "none";
  downloadSpinner.style.display = "none";
  stopBtn.style.display = "none";
  
  if (tabPort) {
      tabPort.postMessage({ action: "stop" });
  }
}

function updateProgressUI() {
  const percent = prompts.length > 0 ? ((currentIndex) / prompts.length) * 100 : 0;
  progressFill.style.width = percent + '%';
}

downloadBtn.addEventListener('click', async () => {
  isRunning = true;
  
  downloadBtn.disabled = true;
  startBtn.disabled = true;
  downloadBtnText.innerText = "DOWNLOADING...";
  downloadSpinner.style.display = "block";
  stopBtn.style.display = "block";

  chrome.tabs.query({active: true, currentWindow: true}, async (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.url.includes('labs.google/fx')) {
      alert("Please navigate to Google AI Studio Flow first.");
      stopGeneration();
      return;
    }
    
    if (tabPort) { tabPort.disconnect(); tabPort = null; }
    await ensureConnection(tab.id);
    
    const handleResponse = (response) => {
        if (!isRunning) return;
        if (tabPort) tabPort.onMessage.removeListener(handleResponse);
        stopGeneration();
        if (response && response.success) {
            alert("All Available Generations Processed!");
        } else if (response && response.error) {
            alert("Download completed with errors: " + response.error);
        }
    };
    
    if (!tabPort) {
        // Fallback resilient messaging if port handshake failed
        try {
            chrome.tabs.sendMessage(tab.id, { action: "downloadAll", settings: getSettings() }, handleResponse);
        } catch(e) {
            alert("Connection error fetching page. Try refreshing Google Flow.");
            stopGeneration();
        }
    } else {
        tabPort.postMessage({ action: "downloadAll", settings: getSettings() });
        tabPort.onMessage.addListener(handleResponse);
    }
  });
});

async function startAutomation(tabId, settings) {
  for (let i = currentIndex; i < prompts.length; i++) {
    if (!isRunning) break;
    currentIndex = i;
    
    updateProgressUI();
    
    // Highlight the "Active" prompt card
    document.querySelectorAll('.prompt-card').forEach((card, idx) => {
        if (idx === currentIndex) {
            card.style.border = '2px solid #00ff88';
            card.style.boxShadow = '0 0 10px rgba(0, 255, 136, 0.4)';
        } else {
            card.style.border = '1px solid #333';
            card.style.boxShadow = 'none';
        }
    });
    
    updateCardStatus(currentIndex, 'processing');
    const prompt = prompts[currentIndex];

    // Auto Reconnect Fix (Handshake verification)
    await ensureConnection(tabId);
    
    if (!tabPort) {
        console.log("No tab port available, marking failed.");
        updateCardStatus(currentIndex, 'failed');
        continue;
    }

    // Await the generation block safely
    const actionResult = await new Promise((resolve) => {
        let timeoutId;
        
        const onDisconnect = () => {
            clearTimeout(timeoutId);
            resolve({ success: false, error: "Port Disconnect / Tab Closed" });
        };
        
        const onPortMessage = (response) => {
            if (response && response.action === "pong") return; // Ignore overlap ping/pong messages
            clearTimeout(timeoutId);
            tabPort.onMessage.removeListener(onPortMessage);
            tabPort.onDisconnect.removeListener(onDisconnect);
            resolve(response);
        };
        
        tabPort.onMessage.addListener(onPortMessage);
        tabPort.onDisconnect.addListener(onDisconnect);
        
        // Failsafe fallback if connection drops (10 minutes)
        timeoutId = setTimeout(() => {
            tabPort.onMessage.removeListener(onPortMessage);
            tabPort.onDisconnect.removeListener(onDisconnect);
            resolve({ success: false, error: "Hard timeout reached (10m)" });
        }, 600000); 
        
        // Fetch fresh settings for exactly this prompt in case the user changed them mid-run
        const freshSettings = getSettings();
        
        tabPort.postMessage({ action: "runAction", prompt: prompt, settings: freshSettings });
    });

    if (!isRunning) break;

    if (!actionResult || !actionResult.success) {
        console.log(`Failed Prompt ${currentIndex}:`, actionResult ? actionResult.error : "Unknown Error");
        updateCardStatus(currentIndex, 'failed');
        continue;
    }
    
    updateCardStatus(currentIndex, 'success');
  }
  
  // Cleanup after loop finishes naturally
  if (currentIndex >= prompts.length && isRunning) {
      stopGeneration();
      progressFill.style.width = '100%';
  }
}
