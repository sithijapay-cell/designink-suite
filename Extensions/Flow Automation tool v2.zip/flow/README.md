# Flow Auto Gen Chrome Extension

A Chrome Extension for "Google AI Studio (Flow)" to automate bulk image generation from a CSV/Text list of prompts.

## Features Directory Structure

```plaintext
c:\My Apps\flow\
├── manifest.json       (Extension Manifest V3 setup)
├── background.js       (Service Worker to open Side Panel on click)
├── sidepanel.html      (Upload UI)
├── sidepanel.js        (CSV logic loop and Message Sender)
├── content_script.js   (Action trigger logic for the React app on labs.google)
└── lib/
    └── papaparse.min.js (CSV Parser offline library)
```

## How to Install (Unpacked Extension)

1. Open Google Chrome.
2. In the URL bar, go to `chrome://extensions/`.
3. In the top right corner, turn on **Developer mode** using the toggle switch.
4. Click the **Load unpacked** button that appears in the top-left menu.
5. In the file browser dialog, navigate to and select the `c:\My Apps\flow` directory.
6. The "Flow Auto Gen" extension should now appear in your list of extensions.

## Usage Guide

1. Navigate to Google AI Studio Flow: `https://labs.google/fx/tools/flow`
2. Pin the "Flow Auto Gen" extension in your Chrome toolbar for easy access.
3. Click the Extension icon. A Chrome side panel will open on the right.
4. Upload your `.txt` or `.csv` file (Ensure it is one prompt per line, no headers).
5. Adjust settings for Models, Aspect Ratio, and Image Count.
6. Click **Start**, and the extension will automate prompt entry, creation button clicks, waiting phases, and download fetching as long as the tab remains open!
