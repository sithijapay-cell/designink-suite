let isStopped = false;

function logAction(msg) {
    console.log("Action Tool:", msg);
    chrome.runtime.sendMessage({ action: "log", message: msg }).catch(() => {});
}

const delay = ms => new Promise(res => setTimeout(res, ms));

async function clickElement(element) {
    if (!element) return;
    const eventProps = { bubbles: true, cancelable: true, view: window };
    element.dispatchEvent(new MouseEvent('mousedown', eventProps));
    await delay(50);
    element.dispatchEvent(new MouseEvent('mouseup', eventProps));
    await delay(50);
    element.click();
    await delay(500); // Standard 500ms delay between actions
}

function getByXPath(path, context = document) {
    return document.evaluate(path, context, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "stop") {
        isStopped = true;
        sendResponse({ success: true });
        return true;
    }
    
    if (request.action === "runAction") {
        isStopped = false;
        runAction(request.prompt, request.settings)
            .then(() => {
                if (!isStopped) {
                    sendResponse({ success: true });
                } else {
                    sendResponse({ success: false, error: 'Stopped by user' });
                }
            })
            .catch(err => {
                logAction(`Error: ${err.message || err.toString()}`);
                sendResponse({ success: false, error: err.message || err.toString() });
            });
        return true; 
    }
});

// The core workflow defined by the Action requirements
async function runAction(prompt, settings) {
    logAction("Step 1 (Focus): Click inside div[data-slate-editor='true']");
    const editor = document.querySelector('div[data-slate-editor="true"]');
    if (!editor) throw new Error("Could not find the prompt editor (data-slate-editor='true').");
    
    editor.focus();
    await clickElement(editor);
    await delay(200);

    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(editor);
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand('delete', false, null);

    logAction("Step 2 (Type): Use document.execCommand('insertText') to paste the prompt");
    document.execCommand('insertText', false, prompt);
    editor.blur();
    await delay(500);

    logAction("Step 3 (Menu): Click the Settings/Model menu button (#radix-:r1d:) && Wait 500ms");
    let settingsBtn = document.querySelector('button[id^="radix-"][aria-expanded]') || document.querySelector('button[id^="radix-"]');
    if (!settingsBtn) {
        // Fallback robust seek
        const createBtn = document.querySelector('button.bMhrec');
        if (createBtn && createBtn.previousElementSibling) {
            settingsBtn = createBtn.previousElementSibling;
        }
    }
    
    if (settingsBtn) {
        if (settingsBtn.getAttribute('aria-expanded') !== 'true') {
            await clickElement(settingsBtn);
        } else {
            // Already open? No problem, just add delay.
            await delay(500); 
        }
    }

    logAction(`Step 4 (Configure): Modifying settings...`);
    logAction(` -> Click "${settings.type}" mode`);
    const typeBtn = getByXPath(`//button[contains(., '${settings.type}')]`);
    if (typeBtn) await clickElement(typeBtn);

    logAction(` -> Click the Aspect Ratio icon`);
    let symbolText = 'crop_16_9';
    const arLower = settings.aspectRatio.toLowerCase();
    if (arLower.includes('portrait') || arLower.includes('9:16')) symbolText = 'crop_9_16';
    else if (arLower.includes('square') || arLower.includes('1:1')) symbolText = 'crop_square';

    let arIcons = Array.from(document.querySelectorAll('i.google-symbols'));
    let arIcon = arIcons.find(icon => icon.textContent.trim() === symbolText);
    if (arIcon) await clickElement(arIcon.closest('button') || arIcon);

    logAction(` -> Click the Count button (${settings.imageCount})`);
    const countBtn = getByXPath(`//button[contains(., '${settings.imageCount}')]`);
    if (countBtn) await clickElement(countBtn);

    // Close the settings menu to keep the UI clean
    document.body.click(); 
    await delay(500);

    logAction("Step 5 (Submit): Click the 'Create' arrow button (button.bMhrec)");
    let genBtn = document.querySelector('button.bMhrec');
    if (!genBtn) throw new Error("Cancel/Submit button not found (.bMhrec).");
    await clickElement(genBtn);

    logAction("Step 6 (Monitor): Wait for the new generation...");
    await monitorAndExport(settings);
}

function monitorAndExport(settings) {
    return new Promise((resolve, reject) => {
        let gridContainer = document.querySelector('[data-testid="virtuoso-scroller"]') || document.querySelector('div[role="main"]') || document.body;
        let resolved = false;

        const observer = new MutationObserver(async (mutations) => {
            if (isStopped) {
                observer.disconnect();
                return reject(new Error("Stopped by user."));
            }

            const menus = Array.from(document.querySelectorAll('[aria-label="More options"]'));
            // Look for unprocessed 3-dot menus
            let newMenu = menus.find(m => !m.hasAttribute('data-action-processed'));

            if (newMenu) {
                const tile = newMenu.closest('[data-tile-id]') || newMenu.closest('div');
                const loadingOverlay = tile ? tile.querySelector('div[role="progressbar"], svg.animate-spin, .loading, [aria-busy="true"]') : null;

                // When new generation is complete (loading overlay removed)
                if (!loadingOverlay) {
                    newMenu.setAttribute('data-action-processed', 'true');
                    observer.disconnect();
                    resolved = true;
                    
                    try {
                        logAction("Step 7 (Export): Click the 3-dot menu on the NEW tile");
                        await clickElement(newMenu);
                        
                        logAction(" -> Click 'Download' from the menu");
                        const downloadXPath = `//button[contains(., 'Download')] | //span[contains(., 'Download')]/ancestor::button | //div[@role="menuitem" and contains(., 'Download')] | //li[contains(., 'Download')]`;
                        const downloadBtn = getByXPath(downloadXPath);
                        if (downloadBtn) await clickElement(downloadBtn);
                        else logAction(" -> Warning: Download button not found in menu.");

                        // CONCURRENCY LOGIC: Resolve immediately so next prompt starts
                        logAction("Step 8 (Next): Action download triggered! Re-looping concurrent logic...");
                        resolve(); 

                        if (settings.resolution && downloadBtn) {
                            logAction(` -> Click the resolution (${settings.resolution})`);
                            await delay(500); 
                            const resText = settings.resolution;
                            const resXPath = `//button[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '${resText.toLowerCase()}')] | //div[@role="menuitem" and contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '${resText.toLowerCase()}')]`;
                            const resBtn = getByXPath(resXPath);
                            if (resBtn) await clickElement(resBtn);
                            else logAction(` -> Warning: Resolution button '${resText}' not found.`);
                        }
                        
                        document.body.click(); 
                    } catch (e) {
                        reject(e);
                    }
                }
            }
        });

        observer.observe(gridContainer, { childList: true, subtree: true, attributes: true });

        // Wait up to two full minutes for generation
        setTimeout(() => {
            if (!resolved) {
                observer.disconnect();
                reject(new Error("Timeout waiting for tile generation."));
            }
        }, 120000);
    });
}
