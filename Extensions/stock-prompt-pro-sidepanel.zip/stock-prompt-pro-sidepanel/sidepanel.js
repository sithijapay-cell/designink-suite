document.addEventListener('DOMContentLoaded', async () => {
    const state = {
        prompts: { scanner: [], keyword: [], uploader: [] },
        isGenerating: false,
        activeModel: "llama-3.3-70b-versatile"
    };

    // --- Tab Navigation Logic ---
    const tabs = document.querySelectorAll('.tab');
    const panels = document.querySelectorAll('.panel');

    tabs.forEach(tab => {
        tab.onclick = () => {
            tabs.forEach(t => t.classList.remove('active'));
            panels.forEach(p => p.classList.remove('active'));
            tab.classList.add('active');
            const target = document.getElementById(`tab-${tab.dataset.tab}`);
            if (target) target.classList.add('active');
        };
    });

    // --- Progress Bar Controller ---
    const setProgress = (current, total, customLabel = null) => {
        const area = document.getElementById('progress-area');
        const fill = document.getElementById('progress-fill');
        const count = document.getElementById('progress-count');
        const label = document.getElementById('progress-label');

        if (total === 0 || current === total) {
            if (label) label.textContent = "Batch Complete";
            setTimeout(() => { if (!state.isGenerating) area.classList.add('hidden'); }, 2000);
        } else {
            area.classList.remove('hidden');
            const pct = (current / total) * 100;
            fill.style.width = `${pct}%`;
            count.textContent = `${current}/${total}`;
            if (label) label.textContent = customLabel || "Generating Batch...";
        }
    };

    // --- Exponential Backoff Helper ---
    const wait = (ms) => new Promise(res => setTimeout(res, ms));

    // --- Groq API Call Implementation ---
    const callGroqModels = async (prompt, imageBase64 = null, currentIdx = 0, totalItems = 0) => {
        const { apiKey } = await chrome.storage.local.get('apiKey');
        if (!apiKey) throw new Error("Groq API Key not found. Please set your Groq API Key in Settings.");

        const url = `https://groq-proxy.designink-metadatagen.workers.dev`;

        const payload = {
            apiKey: apiKey,
            model: state.activeModel,
            messages: [
                {
                    role: "system",
                    content: "You are a Professional AI Image Prompt Engineer. Analyze the subject, style, lighting, and composition of the image."
                },
                {
                    role: "user",
                    content: [{ type: "text", text: prompt }]
                }
            ],
            temperature: 0.7
        };

        if (imageBase64) {
             payload.model = "meta-llama/llama-4-scout-17b-16e-instruct";
             payload.messages[1].content.push({
                 type: "image_url",
                 image_url: { url: imageBase64 }
             });
        }

        const retryDelays = [5000, 10000, 20000]; 
        let attempt = 0;

        while (true) {

            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload)
                });

                if (response.status === 429) {
                    if (attempt >= 10) {
                        throw new Error("FATAL: Groq API Quota Exceeded. Please check your limits.");
                    }
                    
                    setProgress(currentIdx, totalItems, `Quota hit! Auto-pausing 60s for Groq limits... (${10 - attempt} left)`);
                    await wait(60000);
                    attempt++;
                    continue; 
                }

                if (!response.ok) {
                    if (response.status >= 500) {
                        throw new Error("Server temporary error"); 
                    }
                    const errJson = await response.json().catch(() => ({}));
                    const errMsg = errJson.error ? errJson.error.message : "API Error";
                    throw new Error(`FATAL: ${errMsg}`);
                }

                const json = await response.json();
                
                if (!json.choices?.[0]?.message?.content) {
                    throw new Error("FATAL: AI Block: Content blocked or no response.");
                }

                // Reset label if it was changed by rate limit
                const label = document.getElementById('progress-label');
                if (label) label.textContent = "Generating Batch...";

                return json.choices[0].message.content.trim();

            } catch (err) {
                // If it's a fatal error, throw it immediately without retrying
                if (err.message.startsWith("FATAL: ")) {
                    throw new Error(err.message.replace("FATAL: ", ""));
                }
                
                // For other network errors or 500/503 errors, retry
                if (attempt >= 3) throw err; 
                
                const delay = attempt < retryDelays.length ? retryDelays[attempt] : 20000;
                setProgress(currentIdx, totalItems, `Network Error/Timeout: Retrying in ${delay/1000}s...`);
                await wait(delay);
                attempt++;
            }
        }
    };

    // --- Image Normalization to prevent API 400 Errors ---
    const processImageHelper = async (imgElement) => {
        let b64Raw = null;
        if (imgElement.src.startsWith('data:')) {
            b64Raw = imgElement.src;
        } else {
            const blob = await fetch(imgElement.src).then(r => r.blob());
            b64Raw = await new Promise(r => {
                const reader = new FileReader();
                reader.onloadend = () => r(reader.result);
                reader.readAsDataURL(blob);
            });
        }

        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 800; // Optimized size for AI vision tasks
                const MAX_HEIGHT = 800;
                let width = Math.max(2, img.width);
                let height = Math.max(2, img.height);

                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height = Math.round(height * (MAX_WIDTH / width));
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width = Math.round(width * (MAX_HEIGHT / height));
                        height = MAX_HEIGHT;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.fillStyle = '#FFFFFF'; // Fill transparent backgrounds
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0, width, height);
                // Compress to JPEG with 0.75 quality for balancing size and AI visibility
                resolve(canvas.toDataURL('image/jpeg', 0.75));
            };
            img.onerror = () => reject(new Error("Image parsing failed"));
            img.src = b64Raw;
        });
    };

    // --- Bulk Processing Engine ---
    const runBulk = async (items, category, template) => {
        if (state.isGenerating) return;
        state.isGenerating = true;
        
        const resultsBox = document.getElementById(`results-${category}`);
        const total = items.length;

        for (let i = 0; i < total; i++) {
            setProgress(i + 1, total);
            try {
                const item = items[i];
                let b64 = null;

                if (item instanceof HTMLImageElement) {
                    b64 = await processImageHelper(item);
                }

                const resultPrompt = await callGroqModels(template(item), b64, i + 1, total);
                state.prompts[category].push(resultPrompt);
                
                const card = document.createElement('div');
                card.className = 'prompt-card';
                card.innerHTML = `<span class="card-id">#${state.prompts[category].length}</span><p>${resultPrompt}</p>`;
                resultsBox.prepend(card);

                // Throttling: Wait 10 seconds between requests.
                // Ensures we securely fall under the 15 RPM generic Groq Free limits.
                if (i < total - 1) {
                    await wait(10000);
                }

            } catch (err) {
                const errorCard = document.createElement('div');
                errorCard.className = 'prompt-card error';
                errorCard.textContent = `Error on #${i + 1}: ${err.message}`;
                resultsBox.prepend(errorCard);
                // Continue to the next item instead of aborting the entire batch
                continue; 
            }
        }
        state.isGenerating = false;
        setProgress(total, total);
    };

    // --- Scanner Tab logic ---
    document.getElementById('scan-btn').onclick = async () => {
        const grid = document.getElementById('scanner-grid');
        grid.innerHTML = '<p class="panel-hint">Scanning active tab...</p>';
        document.getElementById('select-all-btn').style.display = 'none';
        
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        try {
            const [{ result }] = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => Array.from(document.querySelectorAll('img')).map(i => i.src).filter(s => s.startsWith('http'))
            });

            grid.innerHTML = '';
            if (!result || result.length === 0) {
                grid.innerHTML = '<p class="panel-hint">No images found on page.</p>';
                return;
            }

            result.forEach(src => {
                const img = new Image();
                img.src = src;
                img.onclick = () => {
                    img.classList.toggle('selected');
                    document.getElementById('gen-scanner-btn').disabled = !grid.querySelector('.selected');
                    
                    const images = grid.querySelectorAll('img');
                    const allSelected = images.length > 0 && Array.from(images).every(i => i.classList.contains('selected'));
                    document.getElementById('select-all-btn').textContent = allSelected ? 'Deselect All' : 'Select All';
                };
                grid.appendChild(img);
            });
            document.getElementById('select-all-btn').style.display = 'block';
            document.getElementById('select-all-btn').textContent = 'Select All';
        } catch (e) { grid.innerHTML = '<p class="hint">Permission denied or scan failed.</p>'; }
    };

    document.getElementById('select-all-btn').onclick = () => {
        const grid = document.getElementById('scanner-grid');
        const images = grid.querySelectorAll('img');
        if (images.length === 0) return;

        const allSelected = Array.from(images).every(img => img.classList.contains('selected'));
        
        images.forEach(img => {
            if (allSelected) {
                img.classList.remove('selected');
            } else {
                img.classList.add('selected');
            }
        });
        
        document.getElementById('gen-scanner-btn').disabled = !grid.querySelector('.selected');
        document.getElementById('select-all-btn').textContent = allSelected ? 'Select All' : 'Deselect All';
    };

    document.getElementById('gen-scanner-btn').onclick = () => {
        const selected = Array.from(document.querySelectorAll('#scanner-grid .selected'));
        runBulk(selected, 'scanner', () => "Return ONLY a professional, highly detailed AI art prompt describing this image exactly. Focus on style, lighting, and textures. Do not include any conversational text, introductions, or explanations. Just the prompt itself.");
    };

    // --- Keyword Tab logic ---
    document.getElementById('gen-kw-btn').onclick = () => {
        const input = document.getElementById('kw-input').value.trim();
        const count = parseInt(document.getElementById('kw-count').value);
        const style = document.getElementById('kw-style').value;
        if (!input) return;
        runBulk(Array(count).fill(input), 'keyword', (item) => `Return ONLY an award-winning AI prompt for: ${item} in ${style} style. Do not include any conversational text, introductions, or explanations.`);
    };

    // --- Uploader Tab logic ---
    const fileInp = document.getElementById('file-input');
    fileInp.onchange = () => {
        const grid = document.getElementById('uploader-grid');
        grid.innerHTML = '';
        Array.from(fileInp.files).forEach(file => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.src = e.target.result;
                img.classList.add('selected');
                grid.appendChild(img);
                document.getElementById('gen-upload-btn').disabled = false;
            };
            reader.readAsDataURL(file);
        });
    };

    document.getElementById('gen-upload-btn').onclick = () => {
        const imgs = Array.from(document.querySelectorAll('#uploader-grid img'));
        runBulk(imgs, 'uploader', () => "Return ONLY a detailed, professional AI art prompt capturing every visual detail and mood of this image. Do not include any conversational text, introductions, or explanations. Just the prompt itself.");
    };

    // --- Settings & Utils ---
    document.getElementById('save-settings').onclick = async () => {
        const key = document.getElementById('api-key-input').value.trim();
        await chrome.storage.local.set({ apiKey: key });
        alert("Groq API Settings Saved!");
    };

    const exportCSV = (category) => {
        const data = state.prompts[category];
        if (data.length === 0) return alert("Nothing to export.");
        
        let csvContent = "Prompt\n" + data.map(p => `"${p.replace(/"/g, '""')}"`).join("\n");
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        
        chrome.downloads.download({ url: url, filename: `prompts_${category}.csv` });
    };

    document.getElementById('csv-scanner').onclick = () => exportCSV('scanner');
    document.getElementById('csv-keyword').onclick = () => exportCSV('keyword');
    document.getElementById('copy-scanner').onclick = () => {
        const txt = state.prompts.scanner.join('\n\n');
        if (txt) navigator.clipboard.writeText(txt).then(() => alert("Copied all!"));
    };

    // Init
    const saved = await chrome.storage.local.get(['apiKey']);
    if (saved.apiKey) document.getElementById('api-key-input').value = saved.apiKey;
});